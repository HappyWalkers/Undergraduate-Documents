package code;
import java.awt.Font;
public class ConstVarible {
    public static final String address_home_wifi="192.168.0.104";
    public static final int port=9999;
    public static final String endFlag="!@#$%^&*()";
    public static final String dataPath="C:\\Users\\mashed potato\\Desktop\\vscode\\.vscode\\NOTA_server\\src\\data\\";
    public static final String dataFile="C:\\Users\\mashed potato\\Desktop\\vscode\\.vscode\\NOTA_server\\src\\data";
    public static final String format_txt=".txt";
    public static final String font_String="楷体_GB2312";
    public static final int font_style=Font.PLAIN;
    public static final int font_size=15;
}