#ifndef _TIMER_
#define _TIMER_

#include <ioCC2530.h>
#include "led.h"

void init_timer_1(void);

#endif




