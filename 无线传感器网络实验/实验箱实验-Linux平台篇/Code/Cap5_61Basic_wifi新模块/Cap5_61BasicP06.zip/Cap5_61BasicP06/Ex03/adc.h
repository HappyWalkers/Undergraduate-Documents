
void ADC_Init(void);
unsigned int Get_ADC_Data(void);